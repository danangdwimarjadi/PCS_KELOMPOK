package com.example.toko.response.produk



data class ProdukResponse(
    val success : Boolean,
    val message : String,
    val data: Data
)
