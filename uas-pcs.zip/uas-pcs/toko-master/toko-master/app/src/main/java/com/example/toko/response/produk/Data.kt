package com.example.toko.response.produk

data class Data(
    val produk: List<Produk>
)
