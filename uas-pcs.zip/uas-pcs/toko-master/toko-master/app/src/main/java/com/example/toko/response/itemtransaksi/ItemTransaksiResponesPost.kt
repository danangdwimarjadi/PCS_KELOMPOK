package com.example.toko.response.itemtransaksi

data class ItemTransaksiResponesPost(
    val `data`: Data,
    val message: String,
    val success: Boolean
)

